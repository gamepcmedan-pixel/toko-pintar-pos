package com.tokopintar.nativepos;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

final class ImageMatcher {
    private ImageMatcher() {}
    static Bitmap load(Context context, Uri uri) throws Exception {
        BitmapFactory.Options size=new BitmapFactory.Options();size.inJustDecodeBounds=true;
        try(InputStream is=context.getContentResolver().openInputStream(uri)){BitmapFactory.decodeStream(is,null,size);}
        int scale=1;while(size.outWidth/scale>1200 || size.outHeight/scale>1200)scale*=2;
        BitmapFactory.Options actual=new BitmapFactory.Options();actual.inSampleSize=scale;
        try(InputStream is=context.getContentResolver().openInputStream(uri)) {
            Bitmap b=BitmapFactory.decodeStream(is,null,actual);if(b==null)throw new IllegalArgumentException("Foto tidak dapat dibaca");return b;
        }
    }
    static File save(Context c, Bitmap b, long productId) throws Exception {
        File dir=new File(c.getFilesDir(),"photos");if(!dir.exists()&&!dir.mkdirs())throw new IllegalStateException("Gagal membuat folder foto");
        File target=new File(dir,"product_"+productId+"_"+System.currentTimeMillis()+".jpg");
        int w=b.getWidth(),h=b.getHeight();Bitmap scaled=b;
        if(Math.max(w,h)>700){float ratio=700f/Math.max(w,h);scaled=Bitmap.createScaledBitmap(b,Math.max(1,Math.round(w*ratio)),Math.max(1,Math.round(h*ratio)),true);}
        try(FileOutputStream out=new FileOutputStream(target)){if(!scaled.compress(Bitmap.CompressFormat.JPEG,83,out))throw new IllegalStateException("Gagal menyimpan foto");}
        if(scaled!=b)scaled.recycle();return target;
    }
    static Bitmap loadFile(String path) {
        if(path==null||path.isEmpty())return null;
        BitmapFactory.Options o=new BitmapFactory.Options();o.inSampleSize=2;
        return BitmapFactory.decodeFile(path,o);
    }
    // Average hash (64 bits) is an assistive similarity ranking, not reliable universal object detection.
    static String hash(Bitmap bitmap) {
        Bitmap b=Bitmap.createScaledBitmap(bitmap,8,8,true);long sum=0;int[] lum=new int[64];
        for(int y=0;y<8;y++)for(int x=0;x<8;x++){
            int pixel=b.getPixel(x,y);int v=((pixel>>>16)&255)*299+((pixel>>>8)&255)*587+(pixel&255)*114;
            lum[y*8+x]=v;sum+=v;
        }
        if(b!=bitmap)b.recycle();long bits=0;for(int i=0;i<64;i++)if(lum[i]*64>=sum)bits|=1L<<i;
        return Long.toHexString(bits);
    }
    static int distance(String x,String y) {
        try{return Long.bitCount(Long.parseUnsignedLong(x,16)^Long.parseUnsignedLong(y,16));}catch(Exception e){return 64;}
    }
    static List<StoreDb.Product> ranked(List<StoreDb.Product> products, String hash) {
        List<StoreDb.Product> result=new ArrayList<>();for(StoreDb.Product p:products)if(p.photoHash!=null&&!p.photoHash.isEmpty())result.add(p);
        result.sort(Comparator.comparingInt(p->distance(p.photoHash,hash)));return result;
    }
}

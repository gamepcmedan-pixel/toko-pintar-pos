package com.tokopintar.nativepos;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

final class ThermalPrinter {
    private static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    static boolean hasBluetoothPermission(Activity a) {return Build.VERSION.SDK_INT<31 || a.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;}
    static List<String[]> paired(Activity activity){
        List<String[]> list=new ArrayList<>();BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
        if(a==null||!hasBluetoothPermission(activity))return list;
        Set<BluetoothDevice> devices=a.getBondedDevices();if(devices!=null)for(BluetoothDevice d:devices)list.add(new String[]{d.getName()==null?"Printer BT":d.getName(),d.getAddress()});
        return list;
    }
    static void sendWifi(String host,int port,byte[] payload)throws Exception{
        if(host==null||host.trim().isEmpty()||port<1||port>65535)throw new IllegalArgumentException("IP atau port printer salah");
        try(Socket s=new Socket()){s.connect(new InetSocketAddress(host.trim(),port),5000);s.setSoTimeout(7000);
            try(OutputStream out=s.getOutputStream()){out.write(payload);out.flush();}}
    }
    static void sendBluetooth(Activity activity,String mac,byte[] payload)throws Exception{
        if(!hasBluetoothPermission(activity))throw new SecurityException("Izin Bluetooth belum diberikan");
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null)throw new IllegalStateException("Perangkat tidak memiliki Bluetooth");
        if(!a.isEnabled())throw new IllegalStateException("Aktifkan Bluetooth HP dahulu");
        if(mac==null||mac.isEmpty())throw new IllegalArgumentException("Pilih printer Bluetooth di Pengaturan");
        BluetoothDevice d=a.getRemoteDevice(mac);a.cancelDiscovery();
        try(BluetoothSocket socket=d.createRfcommSocketToServiceRecord(SPP)){
            socket.connect();OutputStream out=socket.getOutputStream();out.write(payload);out.flush();}
    }
}

package com.tokopintar.nativepos;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
    private static final int REQ_CAMERA=101, REQ_GALLERY=102, REQ_BACKUP=103, REQ_RESTORE=104, REQ_BT=105;
    private final ExecutorService printQueue=Executors.newSingleThreadExecutor();
    private StoreDb db;
    private StoreDb.User loggedIn;
    private LinearLayout body;
    private String screen="login";
    private final Map<Long,StoreDb.CartLine> cart=new LinkedHashMap<>();
    private Bitmap scanBitmap;
    private String scanHash="", photoPurpose="";
    private long photoProductId=0, scanProductId=0, lastSaleId=0;
    private int tappedCount=0;
    private String chosenBluetooth="", chosenBluetoothName="";
    private Uri capturedMediaUri;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);db=new StoreDb(this);
        if(state!=null){
            long restoredUser=state.getLong("loggedInId",0);
            if(restoredUser>0)loggedIn=db.sessionUser(restoredUser);
            scanProductId=state.getLong("scanProductId",0);
            photoPurpose=state.getString("photoPurpose","");photoProductId=state.getLong("photoProductId",0);
            String uri=state.getString("capturedMediaUri","");if(!uri.isEmpty())capturedMediaUri=Uri.parse(uri);
        }
        try { if(db.usersCount()==0)showAdminSetup();else if(loggedIn!=null)showDashboard();else showLogin(); }
        catch(Exception e){error("Database tidak dapat dibuka: "+e.getMessage());showFatal(e);}
    }
    private void showFatal(Exception e){
        TextView t=Ui.text(this,"Gagal membuka database. Jangan hapus aplikasi jika masih memiliki data.\n"+e,15,false);
        t.setPadding(30,40,30,40);setContentView(t);
    }
    private boolean admin(){return loggedIn!=null&&"admin".equals(loggedIn.role);}
    private boolean authorized(){if(loggedIn==null){showLogin();return false;}return true;}
    private boolean needsAdmin(){if(!authorized())return false;if(!admin()){error("Hanya admin yang boleh mengakses menu ini");return false;}return true;}
    private void error(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void notice(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void safe(Runnable r){try{r.run();}catch(Exception e){new AlertDialog.Builder(this).setTitle("Tidak berhasil").setMessage(e.getMessage()==null?e.toString():e.getMessage()).setPositiveButton("OK",null).show();}}
    private static String str(EditText e){return e.getText().toString().trim();}
    private static long number(EditText e){return Long.parseLong(str(e).replace(".","").replace(",",""));}
    private static double qty(EditText e){return Double.parseDouble(str(e).replace(",","."));}
    private static String money(long amount){return ReceiptFormatter.money(amount);}
    private void newScreen(String name,String desc,boolean nav){
        screen=name;
        LinearLayout root=Ui.vertical(this);root.setBackgroundColor(Ui.BG);
        TextView banner=Ui.text(this,"TOKO PINTAR  •  POS NATIVE",16,true);banner.setTextColor(Color.WHITE);
        banner.setGravity(Gravity.CENTER_VERTICAL);banner.setBackgroundColor(Ui.INK);
        banner.setPadding(Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18),Ui.dp(this,18));root.addView(banner,new LinearLayout.LayoutParams(-1,-2));
        if(nav&&loggedIn!=null){
            HorizontalScrollView hs=new HorizontalScrollView(this);hs.setHorizontalScrollBarEnabled(false);
            LinearLayout row=Ui.horizontal(this);row.setPadding(8,8,8,8);
            addNav(row,"Beranda",this::showDashboard);addNav(row,"Kasir",this::showPOS);addNav(row,"Stok Kamera",this::showStock);
            if(admin()){addNav(row,"Produk",this::showProducts);addNav(row,"Laporan",this::showReports);addNav(row,"Karyawan",this::showUsers);addNav(row,"Printer",this::showPrinter);addNav(row,"Backup",this::showBackup);}
            addNav(row,"Keluar",()->new AlertDialog.Builder(this).setTitle("Keluar dari akun?").setPositiveButton("Keluar",(d,w)->{loggedIn=null;cart.clear();showLogin();}).setNegativeButton("Batal",null).show());
            hs.addView(row);root.addView(hs,new LinearLayout.LayoutParams(-1,-2));
        }
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        body=Ui.vertical(this);body.setPadding(Ui.dp(this,16),Ui.dp(this,18),Ui.dp(this,16),Ui.dp(this,48));
        Ui.add(body,Ui.text(this,name,25,true),0);if(desc!=null&&!desc.isEmpty())Ui.add(body,Ui.muted(this,desc),4);
        scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }
    private void addNav(LinearLayout parent,String text,Runnable r){
        Button b=Ui.secondary(this,text,r);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.rightMargin=Ui.dp(this,5);parent.addView(b,p);
    }
    private void addCard(LinearLayout c){Ui.add(body,c,14);}
    private TextView caption(String s){return Ui.muted(this,s);}
    private void section(String label){Ui.add(body,Ui.text(this,label,19,true),22);}
    private void showAdminSetup(){
        newScreen("Buat Admin Toko","Aplikasi baru. Buat akun admin sebelum mulai menggunakan kasir.",false);
        LinearLayout card=Ui.card(this);
        Ui.add(card,caption("Username admin: admin"),0);
        EditText pass=Ui.input(this,"Password admin minimal 6 karakter","",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText confirm=Ui.input(this,"Ulangi password","",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Ui.field(card,"Password",pass);Ui.field(card,"Konfirmasi password",confirm);
        Ui.add(card,Ui.button(this,"Buat Akun Admin",()->safe(()->{
            if(!str(pass).equals(str(confirm)))throw new IllegalArgumentException("Konfirmasi password tidak cocok");
            db.addUser("admin",str(pass),"admin");loggedIn=db.login("admin",str(pass));showDashboard();
        })),18);addCard(card);
        Ui.add(body,caption("Semua data tersimpan di HP ini. Data tidak otomatis tersinkron dengan HP lain."),18);
    }
    private void showLogin(){
        newScreen("Masuk ke Toko Pintar","Silakan login sebagai Admin Toko atau Karyawan.",false);
        LinearLayout card=Ui.card(this);
        EditText user=Ui.input(this,"Username","admin");
        EditText pass=Ui.input(this,"Password","",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Ui.field(card,"Username",user);Ui.field(card,"Password",pass);
        Ui.add(card,Ui.button(this,"Masuk",()->safe(()->{
            StoreDb.User u=db.login(str(user),str(pass));if(u==null)throw new IllegalArgumentException("Username atau password salah");
            loggedIn=u;showDashboard();
        })),18);addCard(card);
        Ui.add(body,caption("Jika lupa password admin, diperlukan cadangan data atau pemulihan resmi. Tidak ada password bawaan."),18);
    }
    private void dashboardTile(String title,String value,LinearLayout parent){
        LinearLayout card=Ui.card(this);Ui.add(card,Ui.muted(this,title),0);Ui.add(card,Ui.text(this,value,20,true),7);Ui.add(parent,card,9);
    }
    private void showDashboard(){
        if(!authorized())return;
        newScreen("Beranda","Halo "+loggedIn.username+" · "+(admin()?"Admin Toko":"Karyawan"),true);
        if(admin()){
            dashboardTile("Penjualan hari ini",money(db.todaySales()),body);
            dashboardTile("Total produk",String.valueOf(db.countProducts()),body);
        }
        LinearLayout card=Ui.card(this);
        Ui.add(card,Ui.button(this,"Buka Kasir",this::showPOS),0);
        Ui.add(card,Ui.secondary(this,"Catat Stok melalui Kamera",this::showStock),10);
        if(admin()){
            Ui.add(card,Ui.secondary(this,"Daftarkan Produk",this::showProducts),10);
            Ui.add(card,Ui.secondary(this,"Atur Printer Bluetooth / Wi-Fi",this::showPrinter),10);
            Ui.add(card,Ui.secondary(this,"Kelola Akun Karyawan",this::showUsers),10);
        }
        addCard(card);
        Ui.add(body,caption("Scan foto membandingkan gambar dengan foto referensi katalog. Hasil harus dikonfirmasi, bukan deteksi otomatis universal."),20);
    }
    private void showProducts(){
        if(!needsAdmin())return;
        newScreen("Daftar Produk","Tambah produk dahulu; setelah disimpan, tambahkan foto referensi untuk scan tanpa barcode.",true);
        Ui.add(body,Ui.button(this,"+ Tambah Produk",()->editProduct(new StoreDb.Product())),12);
        EditText search=Ui.input(this,"Cari produk atau kode SKU","");Ui.add(body,search,15);
        Ui.add(body,Ui.secondary(this,"Cari",()->renderProductList(str(search))),8);
        renderProductList("");
    }
    private void renderProductList(String filter){
        // Recreate the list without duplicating old search results.
        if(!"Daftar Produk".equals(screen))return;
        while(body.getChildCount()>5)body.removeViewAt(5);
        List<StoreDb.Product> list=db.products(filter);
        if(list.isEmpty())Ui.add(body,caption("Belum ada produk. Ketuk + Tambah Produk."),16);
        for(StoreDb.Product p:list){
            LinearLayout card=Ui.card(this);
            Ui.add(card,Ui.text(this,p.name,17,true),0);
            Ui.add(card,caption(money(p.price)+" / "+p.unit+"   ·   Stok "+ReceiptFormatter.qty(p.stock)+" "+p.unit),5);
            Ui.add(card,Ui.secondary(this,"Edit / Foto",()->editProduct(p)),10);addCard(card);
        }
    }
    private void editProduct(StoreDb.Product product){
        if(!needsAdmin())return;
        boolean isNew=product.id==0;
        newScreen(isNew?"Tambah Produk":"Edit Produk","Harga adalah harga per satuan (pcs / kg / liter).",true);
        LinearLayout card=Ui.card(this);
        EditText name=Ui.input(this,"Nama produk",product.name);EditText sku=Ui.input(this,"Kode produk (opsional)",product.sku);
        EditText unit=Ui.input(this,"pcs / kg / liter",product.unit);
        EditText price=Ui.input(this,"Harga jual",String.valueOf(product.price),InputType.TYPE_CLASS_NUMBER);
        EditText cost=Ui.input(this,"Harga modal",String.valueOf(product.cost),InputType.TYPE_CLASS_NUMBER);
        EditText stock=Ui.input(this,"Stok awal",ReceiptFormatter.qty(product.stock),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Ui.field(card,"Nama barang",name);Ui.field(card,"SKU / Kode",sku);Ui.field(card,"Satuan",unit);
        Ui.field(card,"Harga jual (Rp)",price);Ui.field(card,"Harga modal (Rp)",cost);
        if(isNew)Ui.field(card,"Stok awal",stock);
        else Ui.add(card,caption("Stok sekarang: "+ReceiptFormatter.qty(product.stock)+" "+product.unit+". Ubah melalui menu Stok."),12);
        Ui.add(card,Ui.button(this,"Simpan Produk",()->safe(()->{
            product.name=str(name);product.sku=str(sku);product.unit=str(unit).isEmpty()?"pcs":str(unit);product.price=number(price);product.cost=number(cost);
            if(isNew)product.stock=qty(stock);
            product.id=db.saveProduct(product);notice("Produk tersimpan");editProduct(db.product(product.id));
        })),18);
        if(!isNew){
            Ui.add(card,Ui.secondary(this,"Ambil Foto Referensi Produk",()->choosePhoto("product",product.id)),10);
            if(product.photo!=null&&!product.photo.isEmpty()){
                Bitmap b=ImageMatcher.loadFile(product.photo);if(b!=null){ImageView im=new ImageView(this);im.setImageBitmap(b);im.setAdjustViewBounds(true);im.setMaxHeight(Ui.dp(this,240));Ui.add(card,im,10);}
            }
        }
        addCard(card);
    }
    private void showPOS(){
        if(!authorized())return;
        newScreen("Kasir","Pilih barang, tentukan jumlah, lalu selesaikan pembayaran.",true);
        LinearLayout basket=Ui.card(this);
        Ui.add(basket,Ui.text(this,"Keranjang",19,true),0);
        long total=0;
        for(StoreDb.CartLine l:cart.values()){
            long lineTotal=Math.round(l.qty*l.product.price);total+=lineTotal;
            LinearLayout row=Ui.horizontal(this);
            TextView label=Ui.text(this,l.product.name+" ("+ReceiptFormatter.qty(l.qty)+")\n"+money(lineTotal),14,false);
            row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            Button remove=Ui.secondary(this,"Hapus",()->{cart.remove(l.product.id);showPOS();});row.addView(remove);
            Ui.add(basket,row,10);
        }
        if(cart.isEmpty())Ui.add(basket,caption("Belum ada barang di keranjang."),10);
        Ui.add(basket,Ui.text(this,"TOTAL: "+money(total),20,true),16);
        Ui.add(basket,Ui.button(this,"Bayar dan Simpan Transaksi",this::paymentDialog),12);
        addCard(basket);
        section("Tambah Barang");
        Ui.add(body,Ui.secondary(this,"Scan Foto Tanpa Barcode",()->choosePhoto("scan-sale",0)),7);
        List<StoreDb.Product> list=db.products("");
        if(list.isEmpty())Ui.add(body,caption("Belum ada produk. Minta admin membuat katalog produk."),12);
        for(StoreDb.Product p:list){
            LinearLayout c=Ui.card(this);Ui.add(c,Ui.text(this,p.name,16,true),0);
            Ui.add(c,caption(money(p.price)+" / "+p.unit+"  ·  Tersedia "+ReceiptFormatter.qty(p.stock)),4);
            Ui.add(c,Ui.secondary(this,"+ Tambah ke Keranjang",()->addToCartDialog(p)),9);addCard(c);
        }
    }
    private void addToCartDialog(StoreDb.Product p){
        StoreDb.Product fresh=db.product(p.id);if(fresh==null){error("Produk sudah tidak tersedia");return;}
        EditText count=Ui.input(this,"Jumlah (boleh desimal untuk kg)","1",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        LinearLayout box=Ui.vertical(this);box.setPadding(24,15,24,0);Ui.add(box,caption("Stok tersedia "+ReceiptFormatter.qty(fresh.stock)+" "+fresh.unit),0);Ui.add(box,count,8);
        new AlertDialog.Builder(this).setTitle("Tambah "+fresh.name).setView(box).setNegativeButton("Batal",null)
                .setPositiveButton("Tambah",(dlg,w)->safe(()->{
                    double q=qty(count);double existing=cart.containsKey(fresh.id)?cart.get(fresh.id).qty:0;
                    if(!Double.isFinite(q)||q<=0||existing+q>fresh.stock+1e-6)throw new IllegalArgumentException("Jumlah tidak valid atau melebihi stok");
                    cart.put(fresh.id,new StoreDb.CartLine(fresh,existing+q));showPOS();
                })).show();
    }
    private void paymentDialog(){
        if(cart.isEmpty()){error("Keranjang masih kosong");return;}
        long total=0;for(StoreDb.CartLine l:cart.values())total+=Math.round(l.qty*l.product.price);
        EditText cash=Ui.input(this,"Uang dibayar",String.valueOf(total),InputType.TYPE_CLASS_NUMBER);
        LinearLayout box=Ui.vertical(this);box.setPadding(24,12,24,4);
        Ui.add(box,Ui.text(this,"Total: "+money(total),18,true),4);Ui.field(box,"Uang diterima (Rp)",cash);
        new AlertDialog.Builder(this).setTitle("Konfirmasi Pembayaran").setView(box).setNegativeButton("Batal",null)
                .setPositiveButton("Simpan",(dialog,which)->safe(()->{
                    long saleId=db.checkout(new ArrayList<>(cart.values()),number(cash),loggedIn.username);
                    lastSaleId=saleId;cart.clear();showReceipt(saleId);
                })).show();
    }
    private void showReceipt(long id){
        if(!authorized())return;
        StoreDb.Sale s=db.sale(id);if(s==null){error("Transaksi tidak ditemukan");showReports();return;}
        newScreen("Struk #"+id,"Transaksi berhasil disimpan. Cetak thermal bila printer sudah disetel.",true);
        String shop=db.setting("shop","TOKO PINTAR");String addr=db.setting("shop_address","");
        int width=Integer.parseInt(db.setting("paper","32"));
        String printed=ReceiptFormatter.format(shop,addr,s,db.saleItems(id),width);
        TextView receipt=Ui.text(this,printed,12,false);receipt.setTypeface(Typeface.MONOSPACE);
        LinearLayout card=Ui.card(this);Ui.add(card,receipt,0);
        Ui.add(card,Ui.button(this,"Cetak Struk Thermal",()->printBytes(ReceiptFormatter.escPos(printed))),10);
        Ui.add(card,Ui.secondary(this,"Bagikan Teks Struk",()->{
            Intent send=new Intent(Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(Intent.EXTRA_TEXT,printed);
            startActivity(Intent.createChooser(send,"Bagikan Struk"));
        }),9);
        Ui.add(card,Ui.secondary(this,"Transaksi Baru",this::showPOS),9);addCard(card);
    }
    private void showStock(){
        if(!authorized())return;
        newScreen("Stok lewat Kamera","Foto barang, pilih produk, ketuk objek untuk menghitung atau isi jumlah manual.",true);
        LinearLayout c=Ui.card(this);
        final EditText[] countRef=new EditText[1];
        Ui.add(c,Ui.button(this,"Ambil Foto Barang",()->choosePhoto("scan-stock",0)),0);
        StoreDb.Product selected=scanProductId==0?null:db.product(scanProductId);
        Ui.add(c,Ui.secondary(this,"Pilih Produk dari Katalog",this::chooseStockProduct),10);
        if(scanBitmap!=null){
            final TextView taps=Ui.text(this,"Ketukan pada foto: "+tappedCount,15,true);
            Ui.add(c,taps,12);
            ImageView photo=new ImageView(this);photo.setImageBitmap(scanBitmap);photo.setAdjustViewBounds(true);photo.setMaxHeight(Ui.dp(this,360));
            photo.setBackground(Ui.background(this,Ui.BG,10,Ui.BORDER));
            photo.setOnClickListener(v->{tappedCount++;taps.setText("Ketukan pada foto: "+tappedCount);
                if(countRef[0]!=null)countRef[0].setText(String.valueOf(tappedCount));});
            Ui.add(c,photo,8);
        }
        if(scanHash!=null && !scanHash.isEmpty()){
            List<StoreDb.Product> matches=ImageMatcher.ranked(db.products(""),scanHash);
            Ui.add(c,Ui.text(this,"Kandidat dari Foto",16,true),15);
            if(matches.isEmpty())Ui.add(c,caption("Belum ada foto referensi. Daftarkan foto di menu Produk."),8);
            int shown=0;for(StoreDb.Product p:matches){if(shown++>=3)break;
                int dist=ImageMatcher.distance(scanHash,p.photoHash);
                String quality=dist<=7?"kemiripan tinggi":dist<=16?"kemiripan sedang":"kemiripan rendah";
                Ui.add(c,Ui.secondary(this,p.name+" · "+quality+" · "+money(p.price),()->{scanProductId=p.id;showStock();}),8);
            }
            Ui.add(c,caption("Periksa bentuk, ukuran, dan label. Pencocokan foto bisa salah terutama barang yang mirip."),8);
        }
        Ui.add(c,Ui.text(this,selected==null?"Produk: belum dipilih":"Produk: "+selected.name+" | Stok "+ReceiptFormatter.qty(selected.stock)+" "+selected.unit+" | Harga "+money(selected.price),16,true),18);
        EditText count=Ui.input(this,"Jumlah barang",String.valueOf(tappedCount>0?tappedCount:1),InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        countRef[0]=count;
        Ui.field(c,"Jumlah / Stok akhir",count);
        Spinner mode=new Spinner(this);String[] values={"Stok Masuk", "Stok Keluar", "Stok Opname (set total)"};
        mode.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values));Ui.field(c,"Jenis pencatatan",mode);
        EditText note=Ui.input(this,"Keterangan (opsional)","");Ui.field(c,"Catatan",note);
        Ui.add(c,Ui.button(this,"Simpan Perubahan Stok",()->safe(()->{
            if(scanProductId==0)throw new IllegalArgumentException("Pilih produk terlebih dahulu");
            double n=qty(count);String kind=mode.getSelectedItemPosition()==0?"MASUK":mode.getSelectedItemPosition()==1?"KELUAR":"OPNAME";
            db.adjustStock(scanProductId,kind,n,loggedIn.username,str(note));
            notice("Stok berhasil dicatat");scanBitmap=null;scanHash="";scanProductId=0;tappedCount=0;showStock();
        })),16);addCard(c);
        section("Riwayat Stok");
        for(String log:db.stockHistory(12))Ui.add(body,caption(log),10);
    }
    private void chooseStockProduct(){
        List<StoreDb.Product> list=db.products("");if(list.isEmpty()){error("Belum ada produk terdaftar");return;}
        String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=list.get(i).name+" · "+money(list.get(i).price);
        new AlertDialog.Builder(this).setTitle("Pilih Produk").setItems(names,(d,idx)->{scanProductId=list.get(idx).id;showStock();}).show();
    }
    private void choosePhoto(String purpose,long productId){
        photoPurpose=purpose;photoProductId=productId;
        new AlertDialog.Builder(this).setTitle("Ambil Foto").setItems(new String[]{"Kamera HP", "Pilih dari Galeri"},(d,which)->{
            Intent i;if(which==0){i=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(i.resolveActivity(getPackageManager())==null){error("Aplikasi kamera tidak tersedia");return;}
                capturedMediaUri=null;
                if(Build.VERSION.SDK_INT>=29){
                    try{
                        ContentValues v=new ContentValues();
                        v.put(MediaStore.Images.Media.DISPLAY_NAME,"toko_pintar_"+System.currentTimeMillis()+".jpg");
                        v.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
                        v.put(MediaStore.Images.Media.RELATIVE_PATH,Environment.DIRECTORY_PICTURES+"/TokoPintar");
                        v.put(MediaStore.Images.Media.IS_PENDING,1);
                        capturedMediaUri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);
                        if(capturedMediaUri!=null){
                            i.putExtra(MediaStore.EXTRA_OUTPUT,capturedMediaUri);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        }
                    }catch(Exception e){capturedMediaUri=null;}
                }
                startActivityForResult(i,REQ_CAMERA);
            }else{i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(i,"Pilih Foto"),REQ_GALLERY);}
        }).show();
    }
    private void handlePhoto(Bitmap b){
        if(b==null){error("Foto tidak ditemukan. Coba lagi.");return;}
        if("product".equals(photoPurpose)){
            safe(()->{if(photoProductId<=0)throw new IllegalArgumentException("Simpan produk sebelum menambah foto");
                File file;
                try { file=ImageMatcher.save(this,b,photoProductId); }
                catch(Exception e){throw new IllegalStateException("Tidak bisa menyimpan foto: "+e.getMessage(),e);}
                db.updatePhoto(photoProductId,file.getAbsolutePath(),ImageMatcher.hash(b));
                notice("Foto referensi disimpan");editProduct(db.product(photoProductId));
            });
        }else if("scan-stock".equals(photoPurpose)){
            scanBitmap=b;scanHash=ImageMatcher.hash(b);tappedCount=0;scanProductId=0;showStock();
        }else if("scan-sale".equals(photoPurpose)){
            String hash=ImageMatcher.hash(b);List<StoreDb.Product> candidates=ImageMatcher.ranked(db.products(""),hash);
            if(candidates.isEmpty()){new AlertDialog.Builder(this).setMessage("Belum ada foto referensi. Hubungi admin untuk mendaftarkan foto produk.").setPositiveButton("OK",null).show();return;}
            List<StoreDb.Product> shown=candidates.subList(0,Math.min(5,candidates.size()));String[] names=new String[shown.size()];
            for(int i=0;i<shown.size();i++)names[i]=shown.get(i).name+" - "+money(shown.get(i).price);
            new AlertDialog.Builder(this).setTitle("Periksa barang sebelum dijual")
                    .setItems(names,(d,index)->addToCartDialog(shown.get(index))).setNegativeButton("Batal",null).show();
        }
    }
    private void showReports(){
        if(!needsAdmin())return;
        newScreen("Laporan Penjualan","Ringkasan omzet dan estimasi laba kotor dari transaksi tersimpan.",true);
        dashboardTile("Omzet hari ini",money(db.todaySales()),body);
        dashboardTile("Seluruh omzet",money(db.totalSales()),body);
        dashboardTile("Estimasi laba kotor",money(db.grossProfit()),body);
        section("Riwayat Transaksi");
        List<StoreDb.Sale> sales=db.recentSales(50);
        if(sales.isEmpty())Ui.add(body,caption("Belum ada transaksi."),8);
        for(StoreDb.Sale s:sales){
            LinearLayout c=Ui.card(this);Ui.add(c,Ui.text(this,"#"+s.id+" • "+money(s.total),17,true),0);
            String date=new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.forLanguageTag("id-ID")).format(new java.util.Date(s.ts));
            Ui.add(c,caption(date+" · Kasir "+s.cashier),5);
            Ui.add(c,Ui.secondary(this,"Lihat / Cetak Struk",()->showReceipt(s.id)),9);addCard(c);
        }
    }
    private void showUsers(){
        if(!needsAdmin())return;
        newScreen("Admin & Karyawan","Admin mengelola akun. Karyawan hanya bisa memakai kasir dan stok kamera.",true);
        Ui.add(body,Ui.button(this,"+ Tambah Akun",this::addUserDialog),13);
        for(StoreDb.User u:db.users()){
            LinearLayout c=Ui.card(this);Ui.add(c,Ui.text(this,u.username+" · "+u.role,17,true),0);
            Ui.add(c,caption(u.active?"Status: Aktif":"Status: Dinonaktifkan"),6);
            Ui.add(c,Ui.secondary(this,"Ganti Password",()->resetPasswordDialog(u)),10);
            if(u.id!=loggedIn.id){
                Ui.add(c,Ui.secondary(this,u.active?"Nonaktifkan Akun":"Aktifkan Akun",()->new AlertDialog.Builder(this).setTitle("Ubah status akun?")
                        .setMessage("Username: "+u.username).setPositiveButton("Ya",(d,w)->safe(()->{
                            db.setUserActive(u.id,!u.active);showUsers();
                        })).setNegativeButton("Batal",null).show()),7);
            }addCard(c);
        }
    }
    private void addUserDialog(){
        LinearLayout box=Ui.vertical(this);box.setPadding(26,8,26,4);
        EditText username=Ui.input(this,"Username","");
        EditText pass=Ui.input(this,"Password minimal 6 karakter","",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        Spinner roles=new Spinner(this);roles.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"karyawan","admin"}));
        Ui.field(box,"Username",username);Ui.field(box,"Password",pass);Ui.field(box,"Peran",roles);
        new AlertDialog.Builder(this).setTitle("Buat Akun").setView(box).setNegativeButton("Batal",null)
            .setPositiveButton("Buat",(d,w)->safe(()->{
                db.addUser(str(username),str(pass),roles.getSelectedItem().toString());showUsers();
            })).show();
    }
    private void resetPasswordDialog(StoreDb.User u){
        EditText pass=Ui.input(this,"Password baru","",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout box=Ui.vertical(this);box.setPadding(24,14,24,0);Ui.add(box,pass,0);
        new AlertDialog.Builder(this).setTitle("Reset password "+u.username).setView(box).setNegativeButton("Batal",null)
                .setPositiveButton("Simpan",(d,w)->safe(()->{db.resetPassword(u.id,str(pass));notice("Password diperbarui");})).show();
    }
    private void showPrinter(){
        if(!needsAdmin())return;
        newScreen("Printer Struk","Bluetooth Classic (SPP) atau Wi-Fi/LAN ESC/POS. Tidak semua printer mendukung protokol ini.",true);
        LinearLayout c=Ui.card(this);
        EditText shop=Ui.input(this,"Nama Toko",db.setting("shop","TOKO PINTAR"));
        EditText address=Ui.input(this,"Alamat / kontak pada struk",db.setting("shop_address",""));
        Spinner type=new Spinner(this);String[] types={"Wi-Fi / LAN (TCP IP)","Bluetooth Classic (SPP)"};
        type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types));
        type.setSelection("BT".equals(db.setting("printer_type","WIFI"))?1:0);
        EditText ip=Ui.input(this,"IP printer (contoh 192.168.1.88)",db.setting("printer_ip",""));
        EditText port=Ui.input(this,"Port printer",db.setting("printer_port","9100"),InputType.TYPE_CLASS_NUMBER);
        Spinner paper=new Spinner(this);String[] paperLabels={"58 mm (32 karakter)","80 mm (48 karakter)"};
        paper.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,paperLabels));
        paper.setSelection("48".equals(db.setting("paper","32"))?1:0);
        Ui.field(c,"Nama Toko",shop);Ui.field(c,"Alamat / Telepon",address);
        Ui.field(c,"Metode Cetak",type);Ui.field(c,"IP Printer Wi-Fi",ip);Ui.field(c,"Port TCP",port);
        Ui.field(c,"Ukuran kertas",paper);
        chosenBluetooth=db.setting("printer_mac","");chosenBluetoothName=db.setting("printer_name","");
        TextView selected=Ui.muted(this,"Bluetooth dipilih: "+(chosenBluetooth.isEmpty()?"Belum ada":chosenBluetoothName+" ("+chosenBluetooth+")"));
        Ui.add(c,selected,12);
        Ui.add(c,Ui.secondary(this,"Pilih Printer Bluetooth yang sudah Pairing",()->{
            if(Build.VERSION.SDK_INT>=31 && !ThermalPrinter.hasBluetoothPermission(this)){
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}
            choosePairedPrinter(selected);
        }),8);
        Runnable save=()->{
            if(str(shop).isEmpty())throw new IllegalArgumentException("Isi nama toko");
            int p=Integer.parseInt(str(port));if(p<1||p>65535)throw new IllegalArgumentException("Port 1 sampai 65535");
            db.putSetting("shop",str(shop));db.putSetting("shop_address",str(address));
            db.putSetting("printer_type",type.getSelectedItemPosition()==1?"BT":"WIFI");
            db.putSetting("printer_ip",str(ip));db.putSetting("printer_port",str(port));
            db.putSetting("paper",paper.getSelectedItemPosition()==1?"48":"32");
            db.putSetting("printer_mac",chosenBluetooth);db.putSetting("printer_name",chosenBluetoothName);
        };
        Ui.add(c,Ui.button(this,"Simpan Pengaturan",()->safe(()->{save.run();notice("Pengaturan printer tersimpan");})),17);
        Ui.add(c,Ui.secondary(this,"Cetak Struk Tes",()->safe(()->{save.run();printBytes(ReceiptFormatter.test(Integer.parseInt(db.setting("paper","32"))));})),9);
        addCard(c);
        Ui.add(body,caption("Wi-Fi perlu jaringan lokal yang sama dan printer menerima RAW TCP ESC/POS. Bluetooth perlu printer SPP yang sudah dipasangkan di Setelan HP. BLE, USB-only, dan protokol khusus membutuhkan driver tambahan."),15);
    }
    private void choosePairedPrinter(TextView selected){
        safe(()->{
            List<String[]> list=ThermalPrinter.paired(this);if(list.isEmpty())throw new IllegalArgumentException("Tidak ada perangkat Bluetooth yang sudah dipasangkan. Pairing dulu melalui Setelan HP.");
            String[] names=new String[list.size()];for(int i=0;i<list.size();i++)names[i]=list.get(i)[0]+" — "+list.get(i)[1];
            new AlertDialog.Builder(this).setTitle("Pilih Printer Bluetooth").setItems(names,(d,i)->{
                chosenBluetoothName=list.get(i)[0];chosenBluetooth=list.get(i)[1];
                selected.setText("Bluetooth dipilih: "+chosenBluetoothName+" ("+chosenBluetooth+")");
            }).show();
        });
    }
    private void printBytes(byte[] payload){
        String type=db.setting("printer_type","WIFI"),host=db.setting("printer_ip",""),mac=db.setting("printer_mac","");
        int port;try{port=Integer.parseInt(db.setting("printer_port","9100"));}catch(Exception e){error("Port printer tidak valid");return;}
        if("BT".equals(type) && !ThermalPrinter.hasBluetoothPermission(this)){
            if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
            error("Izinkan Bluetooth, lalu coba cetak lagi");return;
        }
        notice("Menghubungkan ke printer...");
        printQueue.execute(()->{
            try{
                if("BT".equals(type))ThermalPrinter.sendBluetooth(this,mac,payload);
                else ThermalPrinter.sendWifi(host,port,payload);
                runOnUiThread(()->notice("Data struk telah dikirim ke printer"));
            }catch(Exception e){runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Gagal mencetak")
                    .setMessage(e.getClass().getSimpleName()+": "+e.getMessage()+"\n\nPeriksa protokol ESC/POS, koneksi printer, dan pengaturan.")
                    .setPositiveButton("OK",null).show());}
        });
    }
    private void showBackup(){
        if(!needsAdmin())return;
        newScreen("Backup & Restore","Cadangan lokal berisi produk, akun, transaksi, dan stok. Simpan file di tempat aman.",true);
        LinearLayout c=Ui.card(this);
        Ui.add(c,Ui.text(this,"Cadangkan data",18,true),0);
        Ui.add(c,caption("File JSON cadangan mengandung hash password akun dan data bisnis. Jangan bagikan ke publik."),7);
        Ui.add(c,Ui.button(this,"Export Cadangan JSON",()->{
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");
            i.putExtra(Intent.EXTRA_TITLE,"toko-pintar-backup.json");startActivityForResult(i,REQ_BACKUP);
        }),12);
        Ui.add(c,Ui.text(this,"Pulihkan cadangan",18,true),21);
        Ui.add(c,caption("Restore mengganti seluruh data aplikasi ini. Foto referensi tersimpan di penyimpanan privat HP; ekspor JSON hanya menyimpan metadata, bukan gambar. Simpan foto sumber secara terpisah."),7);
        Ui.add(c,Ui.secondary(this,"Restore dari JSON",()->new AlertDialog.Builder(this).setTitle("Ganti seluruh data?")
                .setMessage("Data sekarang akan ditimpa. Pastikan sudah punya backup sebelum melanjutkan.")
                .setPositiveButton("Pilih File",(d,w)->{
                    Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(i,REQ_RESTORE);
                }).setNegativeButton("Batal",null).show()),12);
        addCard(c);
        Ui.add(body,caption("Aplikasi baru ini menggunakan ID paket baru. Data APK lama tidak dipindahkan otomatis."),18);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(result!=RESULT_OK){
            if(request==REQ_CAMERA&&capturedMediaUri!=null){try{getContentResolver().delete(capturedMediaUri,null,null);}catch(Exception ignored){}capturedMediaUri=null;}
            return;
        }
        try{
            if(request==REQ_CAMERA){
                Bitmap bitmap=null;
                if(capturedMediaUri!=null){
                    try{
                        if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.IS_PENDING,0);getContentResolver().update(capturedMediaUri,v,null,null);}
                        bitmap=ImageMatcher.load(this,capturedMediaUri);
                    }finally{
                        try{getContentResolver().delete(capturedMediaUri,null,null);}catch(Exception ignored){}
                        capturedMediaUri=null;
                    }
                }
                if(bitmap==null&&data!=null&&data.getExtras()!=null){Object x=data.getExtras().get("data");if(x instanceof Bitmap)bitmap=(Bitmap)x;}
                handlePhoto(bitmap);
            }else if(request==REQ_GALLERY){
                if(data==null||data.getData()==null){error("Tidak ada foto dipilih");return;}
                handlePhoto(ImageMatcher.load(this,data.getData()));
            }else if(request==REQ_BACKUP){
                if(data==null||data.getData()==null)return;
                try(OutputStream out=getContentResolver().openOutputStream(data.getData())){
                    if(out==null)throw new IllegalStateException("Tidak bisa menulis file");
                    out.write(db.backup().getBytes(StandardCharsets.UTF_8));out.flush();
                }
                notice("File backup tersimpan");
            }else if(request==REQ_RESTORE){
                if(data==null||data.getData()==null)return;
                byte[] bytes;
                try(InputStream in=getContentResolver().openInputStream(data.getData())){
                    if(in==null)throw new IllegalStateException("Tidak dapat membaca file");
                    java.io.ByteArrayOutputStream o=new java.io.ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
                    while((n=in.read(buffer))!=-1){if(o.size()+n>15*1024*1024)throw new IllegalArgumentException("Backup terlalu besar (>15 MB)");o.write(buffer,0,n);}bytes=o.toByteArray();
                }
                db.restore(new String(bytes,StandardCharsets.UTF_8));loggedIn=null;cart.clear();scanProductId=0;scanBitmap=null;scanHash="";
                notice("Cadangan dipulihkan. Login ulang.");showLogin();
            }
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("Tidak berhasil").setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
    }
    @Override protected void onSaveInstanceState(Bundle out){
        if(loggedIn!=null)out.putLong("loggedInId",loggedIn.id);
        out.putLong("scanProductId",scanProductId);
        out.putString("photoPurpose",photoPurpose);out.putLong("photoProductId",photoProductId);
        if(capturedMediaUri!=null)out.putString("capturedMediaUri",capturedMediaUri.toString());
        super.onSaveInstanceState(out);
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] results){
        super.onRequestPermissionsResult(request,permissions,results);
        if(request==REQ_BT){
            if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)notice("Izin Bluetooth diberikan. Pilih printer kembali.");
            else error("Izin Bluetooth ditolak; cetak Bluetooth tidak tersedia");
        }
    }
    @Override public void onBackPressed(){
        if(loggedIn!=null && !"Beranda".equals(screen))showDashboard();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){printQueue.shutdown();if(db!=null)db.close();super.onDestroy();}
}

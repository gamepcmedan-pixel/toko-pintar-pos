package com.tokopintar.nativepos;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static final int INK=Color.rgb(15,23,42), MUTED=Color.rgb(100,116,139), BLUE=Color.rgb(2,132,199), WHITE=Color.WHITE;
    static final int BG=Color.rgb(248,250,252), BORDER=Color.rgb(226,232,240), GREEN=Color.rgb(4,120,87);
    private Ui() {}
    static int dp(Context c, float value){return (int)(value*c.getResources().getDisplayMetrics().density+.5f);}
    static GradientDrawable background(Context c,int color,int radius, int stroke){
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radius));
        if(stroke!=0)g.setStroke(dp(c,1),stroke);return g;
    }
    static LinearLayout vertical(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;}
    static LinearLayout horizontal(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    static TextView text(Context c,String text,int sp,boolean bold){
        TextView v=new TextView(c);v.setText(text);v.setTextSize(sp);v.setTextColor(INK);
        if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;
    }
    static TextView muted(Context c,String s){TextView v=text(c,s,13,false);v.setTextColor(MUTED);return v;}
    static Button button(Context c,String text,Runnable r){
        Button v=new Button(c);v.setAllCaps(false);v.setText(text);v.setTextSize(14);v.setTextColor(WHITE);
        v.setPadding(dp(c,13),dp(c,9),dp(c,13),dp(c,9));v.setBackground(background(c,BLUE,12,0));
        v.setOnClickListener(view->r.run());return v;
    }
    static Button secondary(Context c,String text,Runnable r){
        Button v=button(c,text,r);v.setTextColor(INK);v.setBackground(background(c,WHITE,12,BORDER));return v;
    }
    static EditText input(Context c,String hint,String initial,int type){
        EditText v=new EditText(c);v.setTextSize(16);v.setSingleLine(true);v.setTextColor(INK);v.setHint(hint);
        v.setInputType(type);v.setText(initial==null?"":initial);v.setSelectAllOnFocus(true);v.setPadding(dp(c,12),dp(c,10),dp(c,12),dp(c,10));
        v.setBackground(background(c,WHITE,12,BORDER));return v;
    }
    static EditText input(Context c,String hint,String initial){return input(c,hint,initial,InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);}
    static void add(LinearLayout parent,View child,int top){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(parent.getContext(),top);parent.addView(child,p);
    }
    static void addSide(LinearLayout parent,View child,int weight){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,weight);p.rightMargin=dp(parent.getContext(),6);parent.addView(child,p);
    }
    static LinearLayout card(Context c){
        LinearLayout l=vertical(c);l.setPadding(dp(c,16),dp(c,15),dp(c,16),dp(c,15));l.setBackground(background(c,WHITE,18,BORDER));return l;
    }
    static void field(LinearLayout parent,String label,View input){
        TextView title=muted(parent.getContext(),label);add(parent,title,12);add(parent,input,5);
    }
}

package com.tokopintar.nativepos;

import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.io.ByteArrayOutputStream;

public final class ReceiptFormatter {
    private ReceiptFormatter() {}
    public static String money(long n){return "Rp"+String.format(Locale.forLanguageTag("id-ID"),"%,d",n);}
    static String qty(double n){if(n==Math.floor(n))return String.valueOf((long)n);return String.format(Locale.US,"%.3f",n).replaceAll("0+$","").replaceAll("\\.$","");}
    static String line(char c,int width){StringBuilder b=new StringBuilder();for(int i=0;i<width;i++)b.append(c);return b.toString();}
    static String pad(String a,String b,int width){
        String left=ascii(a),right=ascii(b);if(right.length()>width)right=right.substring(0,width);
        int room=Math.max(0,width-right.length());if(left.length()>room)left=left.substring(0,room);
        StringBuilder s=new StringBuilder(left);while(s.length()<room)s.append(' ');return s+right;
    }
    static String ascii(String s) {
        String a=Normalizer.normalize(s==null?"":s,Normalizer.Form.NFD).replaceAll("\\p{M}","");
        return a.replaceAll("[^\\x20-\\x7E]","?");
    }
    public static String format(String shop, String address, StoreDb.Sale sale, List<String[]> items, int width){
        width=width<=32?32:48;StringBuilder b=new StringBuilder();
        b.append(ascii(shop)).append('\n');if(address!=null&&!address.isEmpty())b.append(ascii(address)).append('\n');
        b.append(line('-',width)).append('\n');
        b.append("No #").append(sale.id).append(" | ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.forLanguageTag("id-ID")).format(new Date(sale.ts))).append('\n');
        b.append("Kasir: ").append(ascii(sale.cashier)).append('\n').append(line('-',width)).append('\n');
        for(String[] item:items){b.append(ascii(item[0])).append('\n');
            b.append(pad(qty(Double.parseDouble(item[1]))+" x "+money(Long.parseLong(item[2])),money(Long.parseLong(item[3])),width)).append('\n');}
        b.append(line('-',width)).append('\n');b.append(pad("TOTAL",money(sale.total),width)).append('\n');
        b.append(pad("BAYAR",money(sale.paid),width)).append('\n');b.append(pad("KEMBALI",money(sale.paid-sale.total),width)).append('\n');
        b.append(line('-',width)).append('\n').append("Terima kasih!\n\n\n");return b.toString();
    }
    static byte[] escPos(String text){
        ByteArrayOutputStream o=new ByteArrayOutputStream();o.write(0x1B);o.write(0x40);
        byte[] bytes=ascii(text).getBytes(StandardCharsets.US_ASCII);o.write(bytes,0,bytes.length);
        o.write(0x1D);o.write(0x56);o.write(0x42);o.write(0x00);return o.toByteArray();
    }
    static byte[] test(int width){
        return escPos("=== TEST TOKO PINTAR ===\nPrinter ESC/POS "+(width<=32?"58":"80")+" mm\nBluetooth / Wi-Fi\n"+line('-',width<=32?32:48)+"\nOK\n\n\n");
    }
}

package com.tokopintar.nativepos;

import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

final class Crypto {
    private Crypto() {}
    static String salt() {
        byte[] s = new byte[16]; new SecureRandom().nextBytes(s);
        return Base64.encodeToString(s, Base64.NO_WRAP);
    }
    static String hash(String password, String salt) {
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), Base64.decode(salt, Base64.NO_WRAP), 120000, 256);
        try {
            byte[] digest = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
            return Base64.encodeToString(digest, Base64.NO_WRAP);
        } catch (Exception e) { throw new IllegalStateException("Gagal mengamankan password", e); }
        finally { spec.clearPassword(); }
    }
    static boolean matches(String password, String salt, String expected) {
        byte[] x = hash(password, salt).getBytes(StandardCharsets.UTF_8);
        byte[] y = expected.getBytes(StandardCharsets.UTF_8);
        return MessageDigest.isEqual(x, y);
    }
}

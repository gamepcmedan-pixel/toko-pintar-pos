package com.tokopintar.nativepos;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class StoreDb extends SQLiteOpenHelper {
    static final class Product {
        long id; String sku="", name="", unit="pcs", photo="", photoHash="";
        long price, cost; double stock;
        Product() {}
    }
    static final class User {
        long id; String username, role; boolean active;
    }
    static final class CartLine {
        Product product; double qty;
        CartLine(Product p, double q) { product=p; qty=q; }
    }
    static final class Sale {
        long id, total, paid, ts; String cashier;
    }
    static final String[] TABLES = {"users", "products", "sales", "sale_items", "stock_logs", "settings"};

    StoreDb(Context c) { super(c, "tokopintar_native_v2.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, pass_hash TEXT NOT NULL, role TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, sku TEXT, name TEXT NOT NULL, unit TEXT NOT NULL DEFAULT 'pcs', price INTEGER NOT NULL, cost INTEGER NOT NULL DEFAULT 0, stock REAL NOT NULL DEFAULT 0, photo TEXT, photo_hash TEXT)");
        d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, total INTEGER NOT NULL, paid INTEGER NOT NULL, cashier TEXT NOT NULL, ts INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL, product_id INTEGER, product_name TEXT NOT NULL, qty REAL NOT NULL, unit_price INTEGER NOT NULL, unit_cost INTEGER NOT NULL, subtotal INTEGER NOT NULL)");
        d.execSQL("CREATE TABLE stock_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, product_name TEXT, kind TEXT, before_qty REAL, delta REAL, after_qty REAL, actor TEXT, note TEXT, ts INTEGER)");
        d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY, v TEXT NOT NULL)");
        d.execSQL("CREATE INDEX idx_sales_ts ON sales(ts)");
        d.execSQL("CREATE INDEX idx_stock_ts ON stock_logs(ts)");
    }
    @Override public void onUpgrade(SQLiteDatabase d, int oldV, int newV) { /* Future migrations only; never destructive. */ }
    int usersCount() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM users", null)) { return c.moveToFirst()?c.getInt(0):0; }
    }
    void addUser(String username, String password, String role) {
        if (!username.matches("[a-zA-Z0-9_]{3,24}") || password.length()<6) throw new IllegalArgumentException("Username 3-24 karakter huruf/angka/_; password minimal 6 karakter");
        if (!role.equals("admin") && !role.equals("karyawan")) throw new IllegalArgumentException("Role tidak valid");
        ContentValues cv = new ContentValues(); String salt=Crypto.salt();
        cv.put("username", username.toLowerCase(Locale.ROOT)); cv.put("salt",salt); cv.put("pass_hash",Crypto.hash(password,salt)); cv.put("role",role); cv.put("active",1);
        if(getWritableDatabase().insert("users",null,cv)==-1) throw new IllegalArgumentException("Username sudah digunakan");
    }
    User login(String username, String password) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,username,salt,pass_hash,role,active FROM users WHERE username=?", new String[]{username.trim().toLowerCase(Locale.ROOT)})) {
            if(!c.moveToFirst() || c.getInt(5)!=1 || !Crypto.matches(password,c.getString(2),c.getString(3))) return null;
            User u=new User(); u.id=c.getLong(0);u.username=c.getString(1);u.role=c.getString(4);u.active=true;return u;
        }
    }
    User sessionUser(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,username,role,active FROM users WHERE id=?",new String[]{String.valueOf(id)})) {
            if(!c.moveToFirst() || c.getInt(3)!=1)return null;
            User u=new User();u.id=c.getLong(0);u.username=c.getString(1);u.role=c.getString(2);u.active=true;return u;
        }
    }
    List<User> users() {
        List<User> ret=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,username,role,active FROM users ORDER BY role,username",null)) {
            while(c.moveToNext()) {User u=new User();u.id=c.getLong(0);u.username=c.getString(1);u.role=c.getString(2);u.active=c.getInt(3)==1;ret.add(u);}
        } return ret;
    }
    void resetPassword(long id, String pass) {
        if(pass.length()<6)throw new IllegalArgumentException("Password minimal 6 karakter");
        String salt=Crypto.salt();ContentValues cv=new ContentValues();cv.put("salt",salt);cv.put("pass_hash",Crypto.hash(pass,salt));
        getWritableDatabase().update("users",cv,"id=?",new String[]{String.valueOf(id)});
    }
    void setUserActive(long id, boolean active) {
        if (active==false && activeAdminsCount()<2 && isAdmin(id)) throw new IllegalStateException("Minimal satu admin harus aktif");
        ContentValues v=new ContentValues();v.put("active",active?1:0);getWritableDatabase().update("users",v,"id=?",new String[]{String.valueOf(id)});
    }
    private boolean isAdmin(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT role FROM users WHERE id=?",new String[]{String.valueOf(id)})) {return c.moveToFirst() && "admin".equals(c.getString(0));}
    }
    private int activeAdminsCount() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1",null)) {return c.moveToFirst()?c.getInt(0):0;}
    }
    Product product(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,sku,name,unit,price,cost,stock,photo,photo_hash FROM products WHERE id=?",new String[]{String.valueOf(id)})) {
            return c.moveToFirst()?parseProduct(c):null;
        }
    }
    private Product parseProduct(Cursor c) {
        Product p=new Product(); p.id=c.getLong(0);p.sku=c.getString(1);p.name=c.getString(2);p.unit=c.getString(3);
        p.price=c.getLong(4);p.cost=c.getLong(5);p.stock=c.getDouble(6);p.photo=c.getString(7);p.photoHash=c.getString(8);return p;
    }
    List<Product> products(String filter) {
        List<Product> out=new ArrayList<>();String s="%"+(filter==null?"":filter.trim())+"%";
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,sku,name,unit,price,cost,stock,photo,photo_hash FROM products WHERE name LIKE ? OR sku LIKE ? ORDER BY name",new String[]{s,s})) {
            while(c.moveToNext())out.add(parseProduct(c));
        } return out;
    }
    long saveProduct(Product p) {
        if (p.name==null || p.name.trim().isEmpty() || p.price<0 || p.cost<0 || p.stock<0)throw new IllegalArgumentException("Periksa nama, harga, dan stok");
        ContentValues v=new ContentValues();v.put("sku",p.sku);v.put("name",p.name.trim());v.put("unit",p.unit);v.put("price",p.price);v.put("cost",p.cost);v.put("stock",p.stock);
        if(p.id==0) {long id=getWritableDatabase().insertOrThrow("products",null,v);return id;}
        Product old=product(p.id); if(old==null)throw new IllegalStateException("Produk tidak ditemukan");
        if(Math.abs(old.stock-p.stock)>0.0001) throw new IllegalArgumentException("Ubah jumlah melalui menu Stok agar tercatat dalam riwayat");
        getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(p.id)});return p.id;
    }
    void updatePhoto(long productId, String path, String hash) {
        ContentValues v=new ContentValues();v.put("photo",path);v.put("photo_hash",hash);
        getWritableDatabase().update("products",v,"id=?",new String[]{String.valueOf(productId)});
    }
    void adjustStock(long id, String kind, double qty, String actor, String note) {
        if (!(kind.equals("MASUK")||kind.equals("KELUAR")||kind.equals("OPNAME")) || Double.isNaN(qty) || Double.isInfinite(qty) || qty<0)throw new IllegalArgumentException("Jumlah stok tidak valid");
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try {
            Product p=product(id);if(p==null)throw new IllegalArgumentException("Produk tidak ditemukan");
            double after=kind.equals("MASUK")?p.stock+qty:kind.equals("KELUAR")?p.stock-qty:qty;
            if(after < -0.000001)throw new IllegalArgumentException("Stok tidak boleh negatif");
            ContentValues v=new ContentValues();v.put("stock",after);d.update("products",v,"id=?",new String[]{String.valueOf(id)});
            ContentValues log=new ContentValues();log.put("product_id",id);log.put("product_name",p.name);log.put("kind",kind);log.put("before_qty",p.stock);log.put("delta",after-p.stock);log.put("after_qty",after);log.put("actor",actor);log.put("note",note);log.put("ts",System.currentTimeMillis());d.insertOrThrow("stock_logs",null,log);
            d.setTransactionSuccessful();
        }finally {d.endTransaction();}
    }
    long checkout(List<CartLine> lines, long paid, String actor) {
        if(lines.isEmpty())throw new IllegalArgumentException("Keranjang kosong");
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try {
            long total=0;
            for(CartLine l:lines) {if(l.qty<=0||Double.isNaN(l.qty)||Double.isInfinite(l.qty))throw new IllegalArgumentException("Jumlah tidak valid");
                Product fresh=product(l.product.id);if(fresh==null || fresh.stock+0.000001<l.qty)throw new IllegalArgumentException("Stok tidak cukup: "+l.product.name);
                total+=Math.round(l.qty*fresh.price);if(total<0)throw new IllegalArgumentException("Total tidak valid");
            }
            if(paid<total)throw new IllegalArgumentException("Pembayaran kurang");
            ContentValues sv=new ContentValues();sv.put("total",total);sv.put("paid",paid);sv.put("cashier",actor);sv.put("ts",System.currentTimeMillis());
            long saleId=d.insertOrThrow("sales",null,sv);
            for(CartLine l:lines) {
                Product p=product(l.product.id);long sub=Math.round(l.qty*p.price);
                ContentValues si=new ContentValues();si.put("sale_id",saleId);si.put("product_id",p.id);si.put("product_name",p.name);si.put("qty",l.qty);si.put("unit_price",p.price);si.put("unit_cost",p.cost);si.put("subtotal",sub);d.insertOrThrow("sale_items",null,si);
                ContentValues up=new ContentValues();up.put("stock",p.stock-l.qty);d.update("products",up,"id=?",new String[]{String.valueOf(p.id)});
                ContentValues log=new ContentValues();log.put("product_id",p.id);log.put("product_name",p.name);log.put("kind","TERJUAL");log.put("before_qty",p.stock);log.put("delta",-l.qty);log.put("after_qty",p.stock-l.qty);log.put("actor",actor);log.put("note","Transaksi #"+saleId);log.put("ts",System.currentTimeMillis());d.insertOrThrow("stock_logs",null,log);
            }
            d.setTransactionSuccessful();return saleId;
        }finally {d.endTransaction();}
    }
    Sale sale(long id) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,total,paid,cashier,ts FROM sales WHERE id=?",new String[]{String.valueOf(id)})) {
            if(!c.moveToFirst())return null;Sale s=new Sale();s.id=c.getLong(0);s.total=c.getLong(1);s.paid=c.getLong(2);s.cashier=c.getString(3);s.ts=c.getLong(4);return s;
        }
    }
    List<String[]> saleItems(long id) {
        List<String[]> o=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT product_name,qty,unit_price,subtotal FROM sale_items WHERE sale_id=?",new String[]{String.valueOf(id)})) {
            while(c.moveToNext())o.add(new String[]{c.getString(0),String.valueOf(c.getDouble(1)),String.valueOf(c.getLong(2)),String.valueOf(c.getLong(3))});
        }return o;
    }
    List<Sale> recentSales(int limit) {
        List<Sale> o=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,total,paid,cashier,ts FROM sales ORDER BY id DESC LIMIT "+Math.max(1,Math.min(limit,100)),null)) {
            while(c.moveToNext()) {Sale s=new Sale();s.id=c.getLong(0);s.total=c.getLong(1);s.paid=c.getLong(2);s.cashier=c.getString(3);s.ts=c.getLong(4);o.add(s);}
        }return o;
    }
    long totalSales() {try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales",null)){return c.moveToFirst()?c.getLong(0):0;}}
    long todaySales() {
        java.util.Calendar day=java.util.Calendar.getInstance();
        day.set(java.util.Calendar.HOUR_OF_DAY,0);day.set(java.util.Calendar.MINUTE,0);
        day.set(java.util.Calendar.SECOND,0);day.set(java.util.Calendar.MILLISECOND,0);
        long start=day.getTimeInMillis();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0) FROM sales WHERE ts>=?",new String[]{String.valueOf(start)})){
            return c.moveToFirst()?c.getLong(0):0;
        }
    }
    long grossProfit() {try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM((unit_price-unit_cost)*qty),0) FROM sale_items",null)){return c.moveToFirst()?Math.round(c.getDouble(0)):0;}}
    long countProducts() {try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM products",null)){return c.moveToFirst()?c.getLong(0):0;}}
    List<String> stockHistory(int limit) {
        List<String> o=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT kind,product_name,before_qty,after_qty,actor,ts FROM stock_logs ORDER BY id DESC LIMIT "+Math.max(1,Math.min(limit,100)),null)) {
            while(c.moveToNext())o.add(c.getString(0)+" | "+c.getString(1)+" | "+c.getDouble(2)+" -> "+c.getDouble(3)+" | "+c.getString(4)+" | "+new java.text.SimpleDateFormat("dd/MM HH:mm",Locale.forLanguageTag("id-ID")).format(new java.util.Date(c.getLong(5))));
        }return o;
    }
    String setting(String key, String def) {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{key})){return c.moveToFirst()?c.getString(0):def;}
    }
    void putSetting(String k,String v) {ContentValues cv=new ContentValues();cv.put("k",k);cv.put("v",v);getWritableDatabase().insertWithOnConflict("settings",null,cv,SQLiteDatabase.CONFLICT_REPLACE);}
    String backup() throws Exception {
        JSONObject root=new JSONObject();root.put("schema",1);root.put("created",System.currentTimeMillis());
        SQLiteDatabase d=getReadableDatabase();for(String table:TABLES) {
            JSONArray rows=new JSONArray();try(Cursor c=d.rawQuery("SELECT * FROM "+table,null)) {
                while(c.moveToNext()){JSONObject o=new JSONObject();for(int i=0;i<c.getColumnCount();i++){
                    if(c.isNull(i))o.put(c.getColumnName(i),JSONObject.NULL);
                    else if(c.getType(i)==Cursor.FIELD_TYPE_INTEGER)o.put(c.getColumnName(i),c.getLong(i));
                    else if(c.getType(i)==Cursor.FIELD_TYPE_FLOAT)o.put(c.getColumnName(i),c.getDouble(i));
                    else o.put(c.getColumnName(i),c.getString(i));
                }rows.put(o);}
            }root.put(table,rows);
        }return root.toString(2);
    }
    void restore(String json) throws Exception {
        JSONObject root=new JSONObject(json);if(root.getInt("schema")!=1)throw new IllegalArgumentException("Format cadangan tidak kompatibel");
        for(String table:TABLES)if(!root.has(table))throw new IllegalArgumentException("Cadangan tidak lengkap: "+table);
        SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
        try {
            for(int i=TABLES.length-1;i>=0;i--)d.delete(TABLES[i],null,null);
            for(String table:TABLES) {
                JSONArray arr=root.getJSONArray(table);for(int j=0;j<arr.length();j++) {
                    JSONObject o=arr.getJSONObject(j);ContentValues v=new ContentValues();java.util.Iterator<String> keys=o.keys();
                    while(keys.hasNext()){String k=keys.next();Object value=o.get(k);if(value==JSONObject.NULL)v.putNull(k);else if(value instanceof Integer||value instanceof Long)v.put(k,((Number)value).longValue());else if(value instanceof Number)v.put(k,((Number)value).doubleValue());else v.put(k,String.valueOf(value));}
                    d.insertOrThrow(table,null,v);
                }
            }
            if(activeAdminsCount()==0)throw new IllegalArgumentException("Cadangan tidak memiliki admin aktif");
            d.setTransactionSuccessful();
        }finally {d.endTransaction();}
    }
}
